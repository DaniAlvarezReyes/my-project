'use client';
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';

interface FavoritesContextType {
  favorites: string[];
  toggleFavorite: (productId: string) => void;
  isFavorite: (productId: string) => boolean;
  loading: boolean;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (!context) throw new Error('useFavorites must be used within FavoritesProvider');
  return context;
};

export const FavoritesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated } = useAuth();
  const [favorites, setFavorites] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFavorites = async () => {
      if (isAuthenticated && user?.id) {
        const { data } = await supabase
          .from('favorites')
          .select('product_id')
          .eq('user_id', user.id);
        
        if (data) {
          setFavorites(data.map(f => f.product_id));
        }
      } else {
        // Si no hay sesión, favoritos vacíos
        setFavorites([]);
      }
      setLoading(false);
    };

    loadFavorites();
  }, [user, isAuthenticated]);

  const toggleFavorite = useCallback(async (productId: string) => {
    // Si no hay sesión, no permitir añadir favoritos
    if (!isAuthenticated || !user?.id) {
      alert('Inicia sesión para guardar favoritos');
      return;
    }

    const isFav = favorites.includes(productId);

    if (isFav) {
      await supabase
        .from('favorites')
        .delete()
        .eq('user_id', user.id)
        .eq('product_id', productId);
      setFavorites(prev => prev.filter(id => id !== productId));
    } else {
      await supabase
        .from('favorites')
        .insert({ user_id: user.id, product_id: productId });
      setFavorites(prev => [...prev, productId]);
    }
  }, [favorites, user, isAuthenticated]);

  const isFavorite = useCallback((productId: string) => {
    return favorites.includes(productId);
  }, [favorites]);

  return (
    <FavoritesContext.Provider value={{ favorites, toggleFavorite, isFavorite, loading }}>
      {children}
    </FavoritesContext.Provider>
  );
};
