'use client';
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import type { User as SupabaseUser } from '@supabase/supabase-js';
import type { User, LoginForm, RegisterForm } from '@/types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAdmin: boolean;
  login: (credentials: LoginForm) => Promise<{ success: boolean; error?: string }>;
  register: (data: RegisterForm) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  // Cargar usuario desde Supabase al iniciar
  useEffect(() => {
    checkUser();

    // Escuchar cambios de autenticación
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        loadUserProfile(session.user.id, session.user.email || '');
      } else {
        setUser(null);
        setIsAdmin(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const checkUser = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await loadUserProfile(session.user.id, session.user.email || '');
      }
    } catch (error) {
      console.error('Error checking user:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadUserProfile = async (userId: string, email: string) => {
    try {
      // Cargar perfil de profiles (tabla principal)
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (profile) {
        setUser({
          id: profile.id,
          email: profile.email || email,
          name: profile.name,
          lastName: profile.last_name,
          phone: profile.phone,
          createdAt: new Date(profile.created_at),
        });
        
        // Verificar si es admin
        const isAdmin = profile.role === 'admin';
        setIsAdmin(isAdmin);
        
        console.log('Usuario cargado:', profile.email, 'Role:', profile.role, 'IsAdmin:', isAdmin);
        return;
      }

      // Si no existe el perfil, intentar crearlo
      console.log('Perfil no encontrado, creando...');
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const login = async (credentials: LoginForm): Promise<{ success: boolean; error?: string }> => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: credentials.email,
        password: credentials.password,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user) {
        await loadUserProfile(data.user.id, data.user.email || '');
        return { success: true };
      }

      return { success: false, error: 'Error al iniciar sesión' };
    } catch (error: any) {
      return { success: false, error: error.message || 'Error inesperado' };
    }
  };

  const register = async (data: RegisterForm): Promise<{ success: boolean; error?: string }> => {
    try {
      // Validaciones
      if (data.password !== data.confirmPassword) {
        return { success: false, error: 'Las contraseñas no coinciden' };
      }

      if (data.password.length < 6) {
        return { success: false, error: 'La contraseña debe tener al menos 6 caracteres' };
      }

      if (!data.acceptTerms) {
        return { success: false, error: 'Debes aceptar los términos y condiciones' };
      }

      // Determinar si es admin
      const isAdminEmail = data.email === 'danielalvarezreyes99@gmail.com';

      // Registrar en Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: {
            name: data.name,
            last_name: data.lastName,
          }
        }
      });

      if (authError) {
        return { success: false, error: authError.message };
      }

      if (authData.user) {
        // Actualizar perfil con role (el perfil se crea automáticamente por trigger)
        await supabase
          .from('profiles')
          .update({ 
            last_name: data.lastName,
            role: isAdminEmail ? 'admin' : 'customer'
          })
          .eq('id', authData.user.id);

        await loadUserProfile(authData.user.id, data.email);
        return { success: true };
      }

      return { success: false, error: 'Error al registrarse' };
    } catch (error: any) {
      console.error('Register error:', error);
      return { success: false, error: error.message || 'Error inesperado' };
    }
  };

  const logout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setIsAdmin(false);
    } catch (error) {
      console.error('Error al cerrar sesión:', error);
    }
  };

  const updateProfile = async (updatedData: Partial<User>) => {
    if (!user) return;

    try {
      await supabase
        .from('profiles')
        .update({
          name: updatedData.name,
          last_name: updatedData.lastName,
          phone: updatedData.phone,
        })
        .eq('id', user.id);

      setUser({ ...user, ...updatedData });
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        isAdmin,
        login,
        register,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe usarse dentro de AuthProvider');
  }
  return context;
};
