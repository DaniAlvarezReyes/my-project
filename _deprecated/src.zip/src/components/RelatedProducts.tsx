'use client';
import React, { useMemo } from 'react';
import { ProductCard } from './ProductCard';
import { products } from '@/data/products';
import { Product } from '@/types';
import { useRouter } from 'next/navigation';
import { useCart } from '@/context/CartContext';

interface RelatedProductsProps {
  currentProduct: Product;
  maxProducts?: number;
}

export const RelatedProducts: React.FC<RelatedProductsProps> = ({ currentProduct, maxProducts = 4 }) => {
  const router = useRouter();
  const { addItem } = useCart();

  const relatedProducts = useMemo(() => {
    return products
      .filter(p => 
        p.id !== currentProduct.id && 
        (p.category === currentProduct.category || p.brand === currentProduct.brand)
      )
      .slice(0, maxProducts);
  }, [currentProduct, maxProducts]);

  if (relatedProducts.length === 0) return null;

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold mb-6">También te puede interesar</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {relatedProducts.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={() => addItem(product)}
            onViewDetails={() => router.push(`/productos/${product.id}`)}
          />
        ))}
      </div>
    </div>
  );
};
