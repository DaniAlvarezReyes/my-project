'use client';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { loadStripe } from '@stripe/stripe-js';
import { MainNav } from '@/components/MainNav';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/Button';
import { TextField } from '@/components/TextField';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, shipping, tax, total, clearCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [discount, setDiscount] = useState(0);
  const [finalTotal, setFinalTotal] = useState(total);

  const [shippingInfo, setShippingInfo] = useState({
    name: user?.name || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    street: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'España',
  });

  useEffect(() => {
    if (!isAuthenticated) {
      router.push('/auth/login?redirect=/checkout');
    }
    if (items.length === 0) {
      router.push('/carrito');
    }
  }, [isAuthenticated, items, router]);

  useEffect(() => {
    setFinalTotal(total - discount);
  }, [total, discount]);

  const applyCoupon = async () => {
    if (!couponCode.trim()) {
      alert('Ingresa un código de cupón');
      return;
    }

    const { data: coupon, error } = await supabase
      .from('coupons')
      .select('*')
      .eq('code', couponCode.toUpperCase())
      .eq('active', true)
      .single();

    if (error || !coupon) {
      alert('Cupón inválido o no activo');
      return;
    }

    if (coupon.min_purchase && subtotal < coupon.min_purchase) {
      alert(`Compra mínima requerida: €${coupon.min_purchase}`);
      return;
    }

    if (coupon.uses >= coupon.max_uses) {
      alert('Este cupón ha alcanzado el límite de usos');
      return;
    }

    let discountAmount = 0;
    if (coupon.discount_type === 'percentage') {
      discountAmount = (subtotal * coupon.discount_value) / 100;
    } else {
      discountAmount = coupon.discount_value;
    }

    setAppliedCoupon(coupon);
    setDiscount(discountAmount);
    alert(`¡Cupón aplicado! Descuento: €${discountAmount.toFixed(2)}`);
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setDiscount(0);
    setCouponCode('');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setShippingInfo({ ...shippingInfo, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (!shippingInfo.name || !shippingInfo.email || !shippingInfo.street || 
          !shippingInfo.city || !shippingInfo.postalCode) {
        setError('Por favor completa todos los campos requeridos');
        setLoading(false);
        return;
      }

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user?.id,
          user_email: user?.email,
          user_name: user?.name,
          status: 'pending',
          subtotal: subtotal,
          shipping: shipping,
          tax: tax,
          discount: discount,
          coupon_code: appliedCoupon?.code,
          total: finalTotal,
          payment_method: 'card',
          shipping_address: JSON.stringify(shippingInfo),
        })
        .select()
        .single();

      if (orderError) throw orderError;

      if (appliedCoupon) {
        await supabase
          .from('coupons')
          .update({ uses: (appliedCoupon.uses || 0) + 1 })
          .eq('id', appliedCoupon.id);
      }

      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items, orderId: order.id, amount: finalTotal }),
      });

      const { sessionId } = await response.json();
      const stripe = await stripePromise;
      const { error: stripeError } = await stripe!.redirectToCheckout({ sessionId });

      if (stripeError) throw stripeError;
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (!isAuthenticated || items.length === 0) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 space-y-4">
              <h2 className="text-xl font-bold mb-4">Información de Envío</h2>
              {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg">{error}</div>}
              <div className="grid grid-cols-2 gap-4">
                <TextField label="Nombre *" name="name" value={shippingInfo.name} onChange={handleInputChange} required fullWidth />
                <TextField label="Apellidos *" name="lastName" value={shippingInfo.lastName} onChange={handleInputChange} required fullWidth />
              </div>
              <TextField label="Email *" type="email" name="email" value={shippingInfo.email} onChange={handleInputChange} required fullWidth />
              <TextField label="Teléfono" name="phone" value={shippingInfo.phone} onChange={handleInputChange} fullWidth />
              <TextField label="Dirección *" name="street" value={shippingInfo.street} onChange={handleInputChange} required fullWidth />
              <div className="grid grid-cols-3 gap-4">
                <TextField label="Ciudad *" name="city" value={shippingInfo.city} onChange={handleInputChange} required fullWidth />
                <TextField label="Provincia" name="state" value={shippingInfo.state} onChange={handleInputChange} fullWidth />
                <TextField label="CP *" name="postalCode" value={shippingInfo.postalCode} onChange={handleInputChange} required fullWidth />
              </div>
              <Button type="submit" variant="primary" size="lg" fullWidth disabled={loading}>
                {loading ? 'Procesando...' : `Pagar €${finalTotal.toFixed(2)}`}
              </Button>
            </form>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-6 sticky top-4 space-y-4">
              <h2 className="text-xl font-bold mb-4">Resumen</h2>
              {items.map(item => (
                <div key={item.id} className="flex gap-3 pb-3 border-b">
                  <img src={item.product.images[0]} className="w-16 h-16 object-cover rounded" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{item.product.name}</p>
                    <p className="text-xs text-gray-600">Cantidad: {item.quantity}</p>
                    <p className="text-sm font-bold">€{(item.product.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              ))}

              <div className="space-y-2 pt-4 border-t">
                <div className="flex justify-between"><span>Subtotal</span><span>€{subtotal.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>Envío</span><span>€{shipping.toFixed(2)}</span></div>
                <div className="flex justify-between"><span>IVA</span><span>€{tax.toFixed(2)}</span></div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600 font-semibold">
                    <span>Descuento ({appliedCoupon.code})</span>
                    <span>-€{discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-xl font-bold pt-2 border-t">
                  <span>Total</span><span>€{finalTotal.toFixed(2)}</span>
                </div>
              </div>

              <div className="pt-4 border-t">
                <h3 className="font-semibold mb-2">¿Tienes un cupón?</h3>
                {!appliedCoupon ? (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                      placeholder="Código"
                      className="flex-1 px-3 py-2 border rounded-lg"
                    />
                    <button onClick={applyCoupon} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                      Aplicar
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between bg-green-50 p-3 rounded-lg">
                    <span className="font-mono font-bold text-green-800">{appliedCoupon.code}</span>
                    <button onClick={removeCoupon} className="text-red-600 hover:text-red-800">✕</button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer siteName="Sneakers Pro" description="" sections={[]} socialLinks={[]} />
    </div>
  );
}
