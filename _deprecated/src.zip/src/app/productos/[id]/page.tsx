'use client';
import React, { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { MainNav } from '@/components/MainNav';
import { Footer } from '@/components/Footer';
import { Button } from '@/components/Button';
import { Rating } from '@/components/Rating';
import { ProductComments } from '@/components/ProductComments';
import { useCart } from '@/context/CartContext';
import { supabase } from '@/lib/supabase';
import { getProductById } from '@/data/products';

export default function ProductDetailPage() {
  const params = useParams();
  const { addItem } = useCart();
  
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    loadProduct();
  }, [params.id]);

  // Resetear imagen cuando cambia el color
  useEffect(() => {
    console.log('🔄 Color cambió a:', selectedColor, '→ Reseteando imagen a 0');
    setSelectedImage(0);
  }, [selectedColor]);

  // Función para cambiar color con logging
  const handleColorClick = (color: string) => {
    console.log('👆 Click en color:', color);
    setSelectedColor(color);
  };

  const loadProduct = async () => {
    setLoading(true);
    try {
      // Intentar cargar desde Supabase
      const { data: dbProduct } = await supabase
        .from('products')
        .select(`
          *,
          color_variants:product_color_variants(
            id,
            color_name,
            color_hex,
            images,
            stock,
            is_available,
            sizes:product_sizes(*)
          )
        `)
        .eq('id', params.id)
        .single();

      if (dbProduct) {
        console.log('✅ Producto cargado desde Supabase:', dbProduct);
        setProduct(dbProduct);
        
        // Auto-seleccionar primer color si existe
        if (dbProduct.color_variants?.length > 0) {
          setSelectedColor(dbProduct.color_variants[0].color_name);
        }
      } else {
        // Fallback a datos estáticos
        console.log('📦 Usando producto estático');
        const staticProduct = getProductById(params.id as string);
        setProduct(staticProduct);
      }
    } catch (error) {
      console.error('Error:', error);
      const staticProduct = getProductById(params.id as string);
      setProduct(staticProduct);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <MainNav />
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4">Cargando...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50">
        <MainNav />
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Producto no encontrado</h1>
          <Link href="/productos">
            <Button variant="primary">Volver a Productos</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Determinar qué imágenes mostrar - RECALCULA cuando selectedColor cambia
  const hasColorVariants = product.color_variants && product.color_variants.length > 0;
  
  const currentColorVariant = useMemo(() => {
    if (!hasColorVariants || !selectedColor) return null;
    const variant = product.color_variants.find((c: any) => c.color_name === selectedColor);
    console.log('🎨 Color seleccionado:', selectedColor, '→ Variante:', variant);
    return variant;
  }, [hasColorVariants, selectedColor, product.color_variants]);
  
  const imagesToShow = useMemo(() => {
    const images = currentColorVariant?.images || product.images || [];
    console.log('🖼️ Imágenes a mostrar:', images.length, 'imágenes');
    return images;
  }, [currentColorVariant, product.images]);
  
  // Colores disponibles
  const colorsToShow = hasColorVariants ?
    product.color_variants.map((c: any) => c.color_name) :
    (product.colors || []);
  
  // Tallas disponibles
  const sizesToShow = currentColorVariant?.sizes ?
    currentColorVariant.sizes.map((s: any) => s.size) :
    (product.sizes || []);

  const handleAddToCart = () => {
    if (sizesToShow.length > 0 && !selectedSize) {
      alert('Por favor selecciona una talla');
      return;
    }
    if (colorsToShow.length > 0 && !selectedColor) {
      alert('Por favor selecciona un color');
      return;
    }
    addItem(product, quantity, selectedSize, selectedColor);
    alert(`${product.name} añadido al carrito!`);
  };

  const discount = (product.original_price || product.originalPrice) ?
    Math.round((((product.original_price || product.originalPrice) - product.price) / (product.original_price || product.originalPrice)) * 100) : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <MainNav />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex mb-8">
          <ol className="inline-flex items-center space-x-1 md:space-x-3">
            <li><Link href="/" className="text-gray-700 hover:text-blue-600">Inicio</Link></li>
            <li><span className="text-gray-400 mx-2">/</span></li>
            <li><Link href="/productos" className="text-gray-700 hover:text-blue-600">Productos</Link></li>
            <li><span className="text-gray-400 mx-2">/</span></li>
            <li><span className="text-gray-900 font-medium">{product.name}</span></li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* CARRUSEL */}
          <div>
            <div className="bg-white rounded-lg overflow-hidden mb-4 relative">
              {product.badge && (
                <span className={`absolute top-4 left-4 z-10 px-3 py-1 text-xs font-bold text-white rounded-full ${
                  product.badge === 'NUEVO' ? 'bg-blue-600' :
                  product.badge === 'POPULAR' ? 'bg-purple-600' :
                  product.badge === 'OFERTA' ? 'bg-red-600' : 'bg-gray-600'
                }`}>{product.badge}</span>
              )}
              {discount > 0 && (
                <span className="absolute top-4 right-4 z-10 bg-red-500 text-white px-3 py-1 text-sm font-bold rounded-full">
                  -{discount}%
                </span>
              )}
              
              <div className="relative aspect-square">
                <img
                  src={imagesToShow[selectedImage] || 'https://via.placeholder.com/800'}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                
                {imagesToShow.length > 1 && (
                  <>
                    <button
                      onClick={() => setSelectedImage(prev => prev === 0 ? imagesToShow.length - 1 : prev - 1)}
                      className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg"
                    >
                      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </button>
                    <button
                      onClick={() => setSelectedImage(prev => prev === imagesToShow.length - 1 ? 0 : prev + 1)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white p-2 rounded-full shadow-lg"
                    >
                      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                    <div className="absolute bottom-4 right-4 bg-black/60 text-white px-3 py-1 rounded-full text-sm">
                      {selectedImage + 1} / {imagesToShow.length}
                    </div>
                  </>
                )}
              </div>
            </div>

            {imagesToShow.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {imagesToShow.map((image: string, index: number) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`bg-white rounded-lg overflow-hidden border-2 ${
                      selectedImage === index ? 'border-blue-600 ring-2 ring-blue-200' : 'border-gray-200'
                    }`}
                  >
                    <img src={image} alt={`Vista ${index + 1}`} className="w-full h-24 object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* INFO */}
          <div>
            <div className="bg-white rounded-lg p-6">
              <p className="text-sm text-gray-600 mb-2">{product.brand}</p>
              <h1 className="text-3xl font-bold mb-4">{product.name}</h1>

              <div className="flex items-center gap-4 mb-6">
                <Rating value={product.rating} size="lg" showValue />
                <span className="text-sm text-gray-600">({product.reviews} reseñas)</span>
              </div>

              <div className="mb-6">
                <div className="flex items-baseline gap-3">
                  <span className="text-4xl font-bold">€{product.price.toFixed(2)}</span>
                  {(product.original_price || product.originalPrice) && (
                    <span className="text-2xl text-gray-500 line-through">
                      €{(product.original_price || product.originalPrice).toFixed(2)}
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600 mt-2">IVA incluido</p>
              </div>

              <div className="mb-6 pb-6 border-b">
                <h3 className="font-semibold mb-2">Descripción</h3>
                <p className="text-gray-700">{product.description}</p>
              </div>

              {/* SELECTOR DE COLOR */}
              {colorsToShow.length > 0 && (
                <div className="mb-6">
                  <label className="block font-semibold mb-3">
                    Color {selectedColor && `- ${selectedColor}`}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {colorsToShow.map((color: string) => (
                      <button
                        key={color}
                        onClick={() => handleColorClick(color)}
                        className={`px-4 py-2 border-2 rounded-lg font-medium transition ${
                          selectedColor === color
                            ? 'border-blue-600 bg-blue-50 text-blue-600'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* SELECTOR DE TALLA */}
              {sizesToShow.length > 0 && (
                <div className="mb-6">
                  <label className="block font-semibold mb-3">
                    Talla {selectedSize && `- ${selectedSize}`}
                  </label>
                  <div className="grid grid-cols-5 gap-2">
                    {sizesToShow.map((size: string) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`py-3 border-2 rounded-lg font-medium transition ${
                          selectedSize === size
                            ? 'border-blue-600 bg-blue-50 text-blue-600'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* CANTIDAD */}
              <div className="mb-6">
                <label className="block font-semibold mb-3">Cantidad</label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 border-2 border-gray-300 rounded-lg hover:border-gray-400 font-bold"
                  >-</button>
                  <input
                    type="number"
                    min="1"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-20 h-10 text-center border-2 border-gray-300 rounded-lg font-semibold"
                  />
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 border-2 border-gray-300 rounded-lg hover:border-gray-400 font-bold"
                  >+</button>
                </div>
              </div>

              <Button variant="primary" size="lg" fullWidth onClick={handleAddToCart}>
                Añadir al carrito
              </Button>

              <div className="mt-6 space-y-3 text-sm text-gray-600">
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                  </svg>
                  <span>Envío gratuito en pedidos superiores a 50€</span>
                </div>
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  <span>Devoluciones gratuitas en 30 días</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16">
          <ProductComments productId={product.id} />
        </div>
      </div>

      <Footer />
    </div>
  );
}
