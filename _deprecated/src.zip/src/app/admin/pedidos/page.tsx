'use client';
import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function AdminPedidos() {
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    const { data } = await supabase.from('orders').select('*').order('created_at', { ascending: false });
    if (data) setOrders(data);
    setLoading(false);
  };

  const updateStatus = async (orderId: string, newStatus: string) => {
    await supabase.from('orders').update({ status: newStatus }).eq('id', orderId);
    loadOrders();
  };

  const exportCSV = () => {
    const csv = [
      ['ID', 'Fecha', 'Cliente', 'Total', 'Estado'].join(','),
      ...orders.map(o => [o.id.slice(0,8), new Date(o.created_at).toLocaleDateString(), o.user_email, o.total, o.status].join(','))
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pedidos.csv';
    a.click();
  };

  const filteredOrders = filter === 'all' ? orders : orders.filter(o => o.status === filter);

  if (loading) return <div className="text-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div></div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Pedidos ({orders.length})</h1>
        <button onClick={exportCSV} className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">📥 Exportar</button>
      </div>
      <div className="bg-white rounded-lg shadow p-4 flex gap-2">
        {['all', 'pending', 'processing', 'completed', 'cancelled'].map(s => (
          <button key={s} onClick={() => setFilter(s)} className={`px-4 py-2 rounded-lg ${filter === s ? 'bg-blue-600 text-white' : 'bg-gray-100'}`}>
            {s === 'all' ? 'Todos' : s}
          </button>
        ))}
      </div>
      <div className="bg-white rounded-lg shadow">
        <table className="min-w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">ID</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cliente</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filteredOrders.map((order) => (
              <tr key={order.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4 font-mono text-sm">#{order.id.slice(0,8)}</td>
                <td className="px-6 py-4 text-sm">{new Date(order.created_at).toLocaleDateString('es-ES')}</td>
                <td className="px-6 py-4 text-sm">{order.user_email || 'N/A'}</td>
                <td className="px-6 py-4 font-bold">€{order.total.toFixed(2)}</td>
                <td className="px-6 py-4">
                  <select value={order.status} onChange={(e) => updateStatus(order.id, e.target.value)} className={`px-3 py-1 rounded-full text-xs font-semibold ${order.status === 'completed' ? 'bg-green-100 text-green-800' : order.status === 'processing' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>
                    <option value="pending">Pendiente</option>
                    <option value="processing">Procesando</option>
                    <option value="completed">Completado</option>
                    <option value="cancelled">Cancelado</option>
                  </select>
                </td>
                <td className="px-6 py-4"><button onClick={() => setSelectedOrder(order)} className="text-blue-600">👁️ Ver</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between mb-4">
              <h2 className="text-2xl font-bold">Pedido #{selectedOrder.id.slice(0,8)}</h2>
              <button onClick={() => setSelectedOrder(null)} className="text-2xl">×</button>
            </div>
            <div className="space-y-4">
              <div><strong>Cliente:</strong> {selectedOrder.user_email}</div>
              <div><strong>Fecha:</strong> {new Date(selectedOrder.created_at).toLocaleString('es-ES')}</div>
              <div><strong>Total:</strong> €{selectedOrder.total.toFixed(2)}</div>
              <div><strong>Estado:</strong> {selectedOrder.status}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
